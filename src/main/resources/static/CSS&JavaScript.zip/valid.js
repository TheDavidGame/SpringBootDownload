document.querySelector('#validbtn').addEventListener('click',function(e) {
    e.preventDefault();
    //проверка
    let one = ValidMail();
    let two = ValidText();
    let three = ValidPhone();

    if( one  && two  && three  ){
        alert('opa');
    }
});

function ValidMail(){
    if(document.getElementById('email')){
        var myMail = document.getElementById('email').value;
        var re = /^[\w-\.]+@[\w-]+\.[a-z]{2,4}$/i;
        var valid = re.test(myMail);
        if (valid) output = 'Адрес эл. почты введен правильно!';
        else output = 'Адрес электронной почты введен неправильно!';

        let error1 = document.getElementById("err1");
        if(error1){
            error1.remove();
        }
        let sec = document.getElementById('email');
        let error = document.createElement('div');
        error.style.color = 'red';
        error.innerHTML = output;
        error.id = "err1";
        sec.after(error);
        return valid;
    }else{
        return true;
    }

}

function ValidPhone() {
    if(document.getElementById('phone')){
        var re = /\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}/g;
        var myPhone = document.getElementById('phone').value;
        var valid = re.test(myPhone);
        if (valid) output = 'Номер телефона введен правильно!';
        else output = 'Номер телефона введен неправильно!';

        let error1 = document.getElementById("err2");
        if(error1){
            error1.remove();
        }
        let sec = document.getElementById('phone');
        let error = document.createElement('div');
        error.style.color = 'red';
        error.id = "err2";
        error.innerHTML = output;
        sec.after(error);
        return valid;
    }else{
        return true;
    }
}

function ValidText() {
    if(document.getElementById('text')){
        var re = /^[а-яА-Я]+$/g;

        var myText = document.getElementById('text').value;
        var valid = re.test(myText);
        if (valid) output = 'Имя введено правильно!';
        else output = 'Имя введено неправильно!';

        let error1 = document.getElementById("err3");
        if(error1){
            error1.remove();
        }

        let sec = document.getElementById('text');
        let error = document.createElement('div');
        error.style.color = 'red';
        error.id = "err3";
        error.innerHTML = output;
        sec.after(error);
        return valid;
    }else{
        return true;
    }
}